docker exec -e "CORE_PEER_LOCALMSPID=operatorAMSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/operatorA.telecom-network.com/users/Admin@operatorA.telecom-network.com/msp" peer0.operatorA.telecom-network.com peer channel create -o orderer.telecom-network.com:7050 -c  mainchannel -f /etc/hyperledger/configtx/channel1.tx --tls true --cafile "/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/telecom-network.com/orderers/orderer.telecom-network.com/msp/tlscacerts/tlsca.telecom-network.com-cert.pem"



#Join commonchannel by all  peers
docker exec -e "CORE_PEER_LOCALMSPID=operatorAMSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/operatorA.telecom-network.com/users/Admin@operatorA.telecom-network.com/msp"  peer0.operatorA.telecom-network.com peer channel join -b mainchannel.block

docker exec -e "CORE_PEER_LOCALMSPID=operatorBMSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/operatorB.telecom-network.com/users/Admin@operatorB.telecom-network.com/msp"  peer0.operatorB.telecom-network.com peer channel join -b mainchannel.block
